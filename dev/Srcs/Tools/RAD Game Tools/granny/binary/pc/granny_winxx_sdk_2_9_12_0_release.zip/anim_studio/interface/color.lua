-- Some handy color functions

function MakeColor(in_r, in_g, in_b)
   return { in_r, in_g, in_b, 1 }
end

function MakeColorA(in_r, in_g, in_b, in_a)
   return { in_r, in_g, in_b, in_a }
end

