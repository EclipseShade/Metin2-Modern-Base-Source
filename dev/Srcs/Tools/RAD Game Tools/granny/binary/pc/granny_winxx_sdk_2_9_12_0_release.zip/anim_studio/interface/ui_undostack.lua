UndoClass = {
   NeverCollapse = 0,

   NodeMove      = 1,
   NodeSelect    = 2,
   SliderMotion  = 3
}
