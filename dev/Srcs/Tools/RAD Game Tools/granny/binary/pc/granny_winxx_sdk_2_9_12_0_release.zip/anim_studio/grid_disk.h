#ifndef grid_diskidempotent
#define grid_diskidempotent

char const* GridFileList[] = {
"images/9grids/button_pressed.9g",
"images/9grids/button_rest.9g",
"images/9grids/combobox_menu.9g",
"images/9grids/combobox_nonedit.9g",
"images/9grids/dialog.9g",
"images/9grids/dialog_title.9g",
"images/9grids/editbox.9g",
"images/9grids/file_backing.9g",
"images/9grids/itunesbox.9g",
"images/9grids/itunes_dialog.9g",
"images/9grids/node.9g",
"images/9grids/scrollbar_area.9g",
"images/9grids/scrollbar_bg.9g",
"images/9grids/scrollbar_thumb.9g",
"images/9grids/slider_bg.9g",
"images/9grids/slider_bg_small.9g",
"images/9grids/tabview_bottom_active.9g",
"images/9grids/tabview_bottom_inactive.9g",
"images/9grids/tabview_top_active.9g",
"images/9grids/tabview_top_inactive.9g",
};

#endif // grid_diskidempotent
