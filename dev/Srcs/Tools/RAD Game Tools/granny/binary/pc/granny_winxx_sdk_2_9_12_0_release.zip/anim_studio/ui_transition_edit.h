// ========================================================================
// $File: //jeffr/granny_29/statement/ui_transition_edit.h $
// $DateTime: 2011/12/06 12:28:06 $
// $Change: 35917 $
// $Revision: #1 $
//
// $Notice: $
// ========================================================================
#if !defined(UI_TRANSITION_EDIT_H)

#ifndef GRANNY_TYPES_H
#include "granny_types.h"
#endif

struct lua_State;

BEGIN_GRANNY_NAMESPACE;

int Edit_TransitionEdit(lua_State* L);

END_GRANNY_NAMESPACE;

#define UI_TRANSITION_EDIT_H
#endif /* UI_TRANSITION_EDIT_H */
