// ========================================================================
// $Notice: $
// ========================================================================
#if !defined(GSTATE_CPP_SETTINGS_H)

#if defined(_MSC_VER) || defined (__GNUG__)
  #pragma pack(4)
#endif

#if defined(_MSC_VER)
  #pragma warning(disable : 4121)
  #pragma warning(disable : 4127)
#endif

#define GSTATE_CPP_SETTINGS_H
#endif /* GSTATE_CPP_SETTINGS_H */
